# PSI Spectral Library format - Python implementation

For development, run:
```sh
pip install --editable .
```

Or from the root of this repository:
```sh
pip install --editable implementations/python
```

Test with
```
pytest
````
